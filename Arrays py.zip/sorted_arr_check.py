arr = [1, 2, 3, 4, 5]
print("Sorted" if arr == sorted(arr) else "Not Sorted")
