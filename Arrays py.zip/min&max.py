arr = [10, 4, 2, 99, 45, 1]
print("Max:", max(arr))
print("Min:", min(arr))
