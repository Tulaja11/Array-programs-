arr = [1, 2, 3, 4, 5]
print(arr[::-1])  # Using slicing
arr.reverse()     # In-place
print(arr)
